<?php 

	class Pakaian {
		public $warna,
			   $ukuran,
			   $bahan;

		protected $diskon = 0; 

		private $harga;

		public function __construct($warna ="warna",$ukuran ="ukuran",$bahan = "bahan", $harga = 0) {
			$this->warna = $warna;
			$this->ukuran = $ukuran;
			$this->bahan = $bahan;
			$this->harga = $harga; 
		}
		public function getHarga(){
			return $this->harga - ($this->harga * $this->diskon / 100 );
		}

		public function getbuy(){
			return "$this->ukuran,$this->bahan";
		}

		public function getinfoPakaian(){
			$str = " {$this->warna} {$this->getbuy()} (RP.{$this->harga})";
			return $str;
		}
		

	}

	class celana extends Pakaian {
		public $jmlpcs;

		public function __construct( $warna ="warna",$ukuran ="ukuran",$bahan = "bahan",$harga = 0 ,$jmlpcs = 0 ){

			parent::__construct($warna , $ukuran , $bahan , $harga);

			$this->jmlpcs = $jmlpcs;
		}

		public function getinfoPakaian(){
			$str = "Celana : ". parent::getinfoPakaian()." ". "{$this->jmlpcs}/Pcs.";
			return $str;
		}
	}

	class baju extends Pakaian {
		public $jmlbuah;

		public function __construct( $warna ="warna",$ukuran ="ukuran",$bahan = "bahan",$harga = 0 ,$jmlbuah = 0  ){

			parent::__construct( $warna, $ukuran, $bahan, $harga);

			$this->jmlbuah = $jmlbuah;
		}

		public function getinfoPakaian(){
			$str = "Baju : " . parent::getinfoPakaian(). " ". "{$this->jmlbuah}/buah.";
			return $str;
		}

		public function setDiskon ($diskon){
			$this->diskon = $diskon;
		}
	}


	$celana = new celana("Navy", "L", "Waterproof", 50000, 1);
	$baju = new baju("Hijau","XL", "Katun", 75000, 2);

	echo $celana->getinfoPakaian();
	echo "<br>";
	echo $baju->getinfoPakaian();
	echo "<br>";

	$baju->setDiskon(25);
	echo "Harga baju sesudah Diskon : RP.". $baju->getHarga();

?>




 